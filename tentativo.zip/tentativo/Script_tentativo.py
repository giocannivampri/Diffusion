from __initentativo__ import make_correlated_noise, symplectic_map as sy
import numpy as np
import matplotlib.pyplot as plt
import crank_nicolson_numba.generic as cn
import scipy.integrate as integrate

def D_calcolatore(I, epsilon=0.001):
    """Estimates D value by using definitions given for stochastic map.
    
    Parameters
    ----------
    I : float
        sampling point
    epsilon : float
        noise coefficient
    
    Returns
    -------
    float
        diffusion value
    """
    #if I < 0:
     #   return 0.0
    int_result = integrate.quad(
        (lambda th:
         1000*epsilon ** 2
            * (2 * I)
            * np.cos(th) ** 2
            * (np.sqrt(2*I)*np.sin(th)) ** 6),
        0,
        np.pi / 2)
    # Check if int_result is valid, otherwise return 0.0
    #print(int_result[0], int_result[1],(int_result[1] / int_result[0] if int_result[0] != 0.0 else 0.0))
    return (int_result[0] / (np.pi / 2)
            if np.absolute(int_result[1] / int_result[0] if int_result[0] != 0.0 else 1.0) < 0.05 else 0.0)


epsilon=0.001
delta=0.0001
iteration=100000
n_particle=200000

#creating initial distributions
ro=cn.normed_normal_linspace(0.0, 12.5, 3.0, 0.2, 3000)
np.random.seed(6)
u=np.random.normal(3.0, 0.2, n_particle)
np.random.seed(3)
th=np.random.uniform(0.0, np.pi/2, n_particle)
x0=cn.x_from_I_th(u, th)
p0=cn.p_from_I_th(u, th)


#initializing CN
dtau=0.5
motore=cn.cn_generic(0.0, 12.5, ro, dtau, D_calcolatore)
times, current = motore.current(int(iteration/1000), 1)
x, stat=motore.get_data_with_x()


#initializing discrete map
gioeru = sy.generate_instance(0.7, 1.3, 2.1, epsilon, delta, 5.0, x0, p0)
gioeru.compute_common_noise(make_correlated_noise(iteration))
y=gioeru.get_filtered_action()
tempi_mappa, corrente_mappa = gioeru.current_binning(3000)

#plotting
fig, bx=plt.subplots()
fig, dx=plt.subplots()

norm=motore.get_sum()
stat=stat/norm
bx.set_ylabel("\u03C1")
bx.set_xlabel("I")
bx.hist(y, 20, density = True)
bx.plot(x, stat)

dx.set_xlabel("times")
dx.set_ylabel("current")
dx.plot(tempi_mappa, corrente_mappa)
dx.plot(times/dtau*1000, current*n_particle*dtau/1000)

plt.show()